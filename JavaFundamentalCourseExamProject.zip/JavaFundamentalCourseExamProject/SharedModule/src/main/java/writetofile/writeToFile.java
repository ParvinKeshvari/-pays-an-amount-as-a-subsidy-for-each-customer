package writetofile;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class writeToFile {

    public static void writeToJsonFile(List List , String fileName) {

        if(List.size() > 0) {



            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String json = gson.toJson(List);
            try (FileWriter writer = new FileWriter(fileName,true)) {
                System.out.println(List);
                gson.toJson(List, writer);
            } catch (IOException e) {
                e.printStackTrace();
            }


        }


    }

    public static void writeToXMLFile(List list , String fileName) {

        DocumentBuilderFactory dFact = DocumentBuilderFactory.newInstance();
        DocumentBuilder build = null;
        try {
            build = dFact.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        }
        Document doc = build.newDocument();

        Element Details = doc.createElement("Customers");
        doc.appendChild(Details);

        for(int i=0; i<list.size(); i += 1 ) {

            Element name = doc.createElement("Items");

            name.appendChild(doc.createTextNode(String.valueOf(list.get(i))));
            Details.appendChild(name);

   /*         Element id = doc.createElement("ID");
            id.appendChild(doc.createTextNode(String.valueOf(list.get(i + 1))));
            Details.appendChild(id);


            Element mmi = doc.createElement("Age");
            mmi.appendChild(doc.createTextNode(String.valueOf(list.get(i + 2))));
            Details.appendChild(mmi);*/

        }
        // Save the document to the disk file
        TransformerFactory tranFactory = TransformerFactory.newInstance();
        Transformer aTransformer = null;
        try {
            aTransformer = tranFactory.newTransformer();
        } catch (TransformerConfigurationException e) {
            throw new RuntimeException(e);
        }

        // format the XML nicely
        aTransformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");

        aTransformer.setOutputProperty(
                "{http://xml.apache.org/xslt}indent-amount", "4");
        aTransformer.setOutputProperty(OutputKeys.INDENT, "yes");

        DOMSource source = new DOMSource(doc);
        try {

            FileWriter fos = new FileWriter(fileName);
            StreamResult result = new StreamResult(fos);
            try {
                aTransformer.transform(source, result);
            } catch (TransformerException e) {
                throw new RuntimeException(e);
            }

        } catch (IOException e) {

            e.printStackTrace();
        }


    }



}
