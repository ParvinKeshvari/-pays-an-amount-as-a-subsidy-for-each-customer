package dbcp;

import org.apache.commons.dbcp2.BasicDataSource;
import org.jasypt.util.text.AES256TextEncryptor;

import javax.sql.DataSource;
import java.util.ResourceBundle;

public class ExecuteDBCP {


    public static BasicDataSource ds;
    public static ResourceBundle bundle = ResourceBundle.getBundle("DB");


/**
     * This method creates and returns a datasource with jdbc properties
     * defined in DB.properties file
     */

public static DataSource getDataSource() {
    String DB_ULR,DataBase,user,password,pCon ;

    if (ds == null) {

        user=bundle.getString("user");
        DB_ULR = bundle.getString("DB_ULR");
        DataBase =bundle.getString("databaseName");
        pCon = bundle.getString("pCon");
        AES256TextEncryptor textEncryptor = new AES256TextEncryptor();
        textEncryptor.setPassword("123");
        password = textEncryptor.decrypt(bundle.getString("password"));
        ds = new BasicDataSource();

        //ds.setDriverClassName(bundle.getString("jdbcdriver"));
        ds.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
/*        ds.setUrl(bundle.getString("url"));
        ds.setUsername(bundle.getString("user"));*/
        ds.setUrl(DB_ULR + ";databaseName="+DataBase + pCon);
        ds.setUsername(user);
        ds.setPassword(password);
    }
    return ds;
}



}
