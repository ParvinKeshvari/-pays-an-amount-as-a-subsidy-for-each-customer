package output;

import dbcp.ExecuteDBCP;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;

import static writetofile.writeToFile.writeToJsonFile;
import static writetofile.writeToFile.writeToXMLFile;

/**
 * This class has methode for output part, and also main methode
 */

public class OutputClient2 {
    public static void main(String[] args) {
        searchInCustomers();
    }

    public static List<Object> objectList = new ArrayList<>();

    /**
     * This methode executes a select for find special customer
     */
    public static void searchInCustomers(){
        String query2 = "select * from Customers " +
                "inner join Accounts on ..." +
                "where balance > ?";

        String query = "SELECT Customers.CustomerId, Customers.CustomerName, Customers.CustomerSurname, Customers.CustomerNationalId, Accounts.AccountNumber, Accounts.AccountOpenDate, Accounts.AccountBalance " +
                "FROM  Accounts INNER JOIN Customers ON Accounts.AccountCustomerId = Customers.CustomerId " +
                "WHERE  (Accounts.AccountBalance > ?) ORDER BY Customers.CustomerId";
        // ("SELECT Customers.CustomerId, Customers.CustomerName, Customers.CustomerSurname, Customers.CustomerNationalId, Accounts.AccountNumber, Accounts.AccountOpenDate, Accounts.AccountBalance FROM  Accounts INNER JOIN Customers ON Accounts.AccountCustomerId = Customers.CustomerId WHERE  (Accounts.AccountBalance > 10025) ORDER BY Customers.CustomerId");

        /**
         * Get connection from dbcp datasource
         */
        DataSource ds = ExecuteDBCP.getDataSource();
        Connection conn = null;
        PreparedStatement pStmt = null;

        try {
            conn = ds.getConnection();
            pStmt = conn.prepareStatement(query);
            pStmt.setLong(1, 10089);
            ResultSet resultSet = pStmt.executeQuery();
            manageOutpute(resultSet);
        }catch (SQLException e)
        {
            System.out.println(e.getMessage());
        } finally {
            try{
                pStmt.close();
            }catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }


    }


    /**
     * This method converts resultset Dto and calls generic
     * method which writes this data to json file
     * @param resultSet
     */
    public static void manageOutpute(ResultSet resultSet){


        ResourceBundle bundle = ResourceBundle.getBundle("DB");
        String root = System.getProperty("user.dir");
        String fileOutputJSONFile = bundle.getString("fileOutputJSONFile");
        String fileOutputXMLFile = bundle.getString("fileOutputXMLFile");


        //String filepathAccounts = "\\src\\main\\resources\\data\\ErrorJSONFile.json";
        String abspathfileErrorJSONFile = root + fileOutputJSONFile;
        String abspathfileErrorXMLFile = root + fileOutputXMLFile;

        int o = 0;
        OutputDTO output= new OutputDTO();
        try
        {
            while (resultSet.next()){
                output = OutputDTO.parse(resultSet);

                //If you want it in a specific datatype, use Stream.of(object):
                List<Object> list = Collections.singletonList(output);

                // this generic method writes error created in pervious step in json file.
                writeToJsonFile( list,abspathfileErrorJSONFile);

                objectList.addAll(list);

            }
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }


        writeToXMLFile(objectList , abspathfileErrorXMLFile);


    }

}
