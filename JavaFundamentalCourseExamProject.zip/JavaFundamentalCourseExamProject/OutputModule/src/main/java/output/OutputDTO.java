package output;


import java.sql.ResultSet;
import java.sql.SQLException;

public class OutputDTO {

    public int customerId;
    public String customerName;
    public String customerSurname;
    public String customerNationalId;
    public String accountNumber;
    public int accountOpenDate;
    public int accountBalance;


    public OutputDTO()
    {

    }

    public OutputDTO(int customerId, String customerName, String customerSurname, String customerNationalId, String accountNumber, int accountOpenDate, int accountBalance) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerSurname = customerSurname;
        this.customerNationalId = customerNationalId;
        this.accountNumber = accountNumber;
        this.accountOpenDate = accountOpenDate;
        this.accountBalance = accountBalance;
    }

    public static OutputDTO parse (ResultSet resultSet )
    {
        try {

        int customerId = resultSet.getInt("customerId");
        String customerName = resultSet.getString("customerName");
        String customerSurname = resultSet.getString("customerSurname");
        String customerNationalId = resultSet.getString("customerNationalId");
        String accountNumber = resultSet.getString("accountNumber");
        int accountOpenDate =  resultSet.getInt("accountOpenDate");
        int accountBalance =  resultSet.getInt("accountBalance");

            OutputDTO outputDTO = new OutputDTO( customerId,customerName,customerSurname,customerNationalId,accountNumber,accountOpenDate,accountBalance);
            return outputDTO;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerSurname() {
        return customerSurname;
    }

    public void setCustomerSurname(String customerSurname) {
        this.customerSurname = customerSurname;
    }

    public String getCustomerNationalId() {
        return customerNationalId;
    }

    public void setCustomerNationalId(String customerNationalId) {
        this.customerNationalId = customerNationalId;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public int getAccountOpenDate() {
        return accountOpenDate;
    }

    public void setAccountOpenDate(int accountOpenDate) {
        this.accountOpenDate = accountOpenDate;
    }

    public long getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(int accountBalance) {
        this.accountBalance = accountBalance;
    }

    @Override
    public String toString() {
        return "OutputDTO{" +
                "customerId=" + customerId +
                ", customerName='" + customerName + '\'' +
                ", customerSurname='" + customerSurname + '\'' +
                ", customerNationalId='" + customerNationalId + '\'' +
                ", accountNumber='" + accountNumber + '\'' +
                ", accountOpenDate=" + accountOpenDate +
                ", accountBalance=" + accountBalance +
                '}';
    }
}
