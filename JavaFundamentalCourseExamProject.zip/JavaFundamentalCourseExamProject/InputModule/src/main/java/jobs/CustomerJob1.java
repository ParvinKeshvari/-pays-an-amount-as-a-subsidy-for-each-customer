package jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import static manager.DTOManagment.manageCustomers;


public class CustomerJob1 implements Job {
    final private int START_INDEX = 1;
    final private int MAX_SIZE = 100;

    /**
     * This method getsstart index and max size to iterate over accounts for one job (thread)
     */
    public void execute(JobExecutionContext context) {
        System.out.println("CustomerJob1 is running");
        manageCustomers(START_INDEX, MAX_SIZE);
    }

}