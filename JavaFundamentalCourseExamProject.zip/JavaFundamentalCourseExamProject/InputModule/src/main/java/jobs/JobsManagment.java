package jobs;

import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;

import java.util.Date;

public class JobsManagment {
public static void executeCustomerJobs()
{
    try{
        // set job details.
        JobDetail customerJob1 = JobBuilder.newJob(CustomerJob1.class)
                .withIdentity("customerJob1","group1").build();

        JobDetail customerJob2 = JobBuilder.newJob(CustomerJob2.class)
                .withIdentity("customerJob2","group1").build();

/*        JobDetail customerJob3 = JobBuilder.newJob(customerJob3.class)
                .withIdentity("customerJob3","group1").build();*/
        // Set the scheduler timings
        Trigger trigger1 = TriggerBuilder.newTrigger()
                .withIdentity("trigger1","group1")
                .withSchedule(SimpleScheduleBuilder.simpleSchedule())
                .startAt(new Date(System.currentTimeMillis() + 5000)).build();
        Trigger trigger2 = TriggerBuilder.newTrigger()
                .withIdentity("trigger2","group1")
                .withSchedule(SimpleScheduleBuilder.simpleSchedule())
                .startAt(new Date(System.currentTimeMillis() + 5000)).build();
/*        Trigger trigger3 = TriggerBuilder.newTrigger()
                .withIdentity("trigger3","group1")
                .withSchedule(SimpleScheduleBuilder.simpleSchedule())
                .startAt(new Date(System.currentTimeMillis() + 5000)).build();*/
//Execute the job.
        Scheduler scheduler =
                new StdSchedulerFactory().getScheduler();
        scheduler.start();
        scheduler.scheduleJob(customerJob1, trigger1);
        scheduler.scheduleJob(customerJob2, trigger2);
/*        scheduler.scheduleJob(customerJob3, trigger3);*/

    }
    catch(Exception e)
    {
        e.printStackTrace();
    }
}



    public static void executeAccountJobs()
    {
        try{
            // set job details.
            JobDetail accountJob1 = JobBuilder.newJob(AccountJob1.class)
                    .withIdentity("accountJob1","group1").build();

            JobDetail accountJob2 = JobBuilder.newJob(AccountJob2.class)
                    .withIdentity("accountJob2","group1").build();

     /*       JobDetail accountJob3 = JobBuilder.newJob(AccountJob3.class)
                    .withIdentity("accountJob3","group1").build();*/
            // Set the scheduler timings
            Trigger trigger3 = TriggerBuilder.newTrigger()
                    .withIdentity("trigger3","group1")
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule())
                    .startAt(new Date(System.currentTimeMillis() + 5000)).build();
            Trigger trigger4 = TriggerBuilder.newTrigger()
                    .withIdentity("trigger4","group1")
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule())
                    .startAt(new Date(System.currentTimeMillis() + 5000)).build();
/*            Trigger trigger3 = TriggerBuilder.newTrigger()
                    .withIdentity("trigger3","group1")
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule())
                    .startAt(new Date(System.currentTimeMillis() + 5000)).build();*/
//Execute the job.
            Scheduler scheduler =
                    new StdSchedulerFactory().getScheduler();
            scheduler.start();
            scheduler.scheduleJob(accountJob1, trigger3);
            scheduler.scheduleJob(accountJob2, trigger4);
          /*  scheduler.scheduleJob(customerJob3, trigger3);*/

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

    }


}
