package jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;

import static manager.DTOManagment.manageAccounts;

/**
 * This class is for creating an account job object
 *
 */
public class AccountJob2 implements Job {
    final private int START_INDEX = 100;
    final private int MAX_SIZE = 200;

    /**
     * This method getsstart index and max size to iterate over accounts for one job (thread)
     */
    public void execute(JobExecutionContext context) {
        System.out.println("AccountJob2 is running");
        manageAccounts(START_INDEX, MAX_SIZE);
    }

}