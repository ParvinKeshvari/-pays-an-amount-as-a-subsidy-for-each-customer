package validations;

import mainobject.Account;
import mainobject.Customer;

import java.util.Calendar;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

/**
 * This class has Predicates for validate Account
 * @author Keshvari
 */

public class AccountPredicates {

    public static Predicate<Account> isBalanceInvalid()
    {
        return p -> p.getAccountBalance() > p.getAccountLimit();
    }

    public static Predicate<Account> isTypeInvalid()
    {
        return p -> {
            return p.getAccountType() > 4;
        };
    }

    public static Predicate<Account> isNumbervalid()
    {
        return p -> p.getAccountNumber().length() != 22;
    }

/*    public static Predicate<Accounts> isCustomerIdInvalid(List<Long> customerIds)
    {

    }*/
    public static List<Account> filterInvalidAccounts (List<Account> accounts,Predicate<Account> predicate)
    {
        return accounts.stream()
                .filter(predicate)
                .collect(Collectors.toList());

    }

}
