package validations;

import mainobject.Customer;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * This class has Predicates for validate Customer
 * @author Keshvari
 */
public class CustomerPredicates {

    public static Predicate<Customer> isBirthDateInvalid()
    {
      /*  Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR , 1995);
        Date validDate = calendar.getTime();*/
        return p -> p.getCustomerBirthDate() < (1350);//1373

    }

    public static Predicate<Customer> isNationalIdInvalid()
    {
        return p -> String.valueOf(p.getCustomerNationalId()).length() != 10;
    }

    public static List<Customer> filterInvalidCustomers (List<Customer> customers,Predicate<Customer> predicate)
    {
        return customers.stream()
                .filter(predicate)
                .collect(Collectors.toList());

    }



}
