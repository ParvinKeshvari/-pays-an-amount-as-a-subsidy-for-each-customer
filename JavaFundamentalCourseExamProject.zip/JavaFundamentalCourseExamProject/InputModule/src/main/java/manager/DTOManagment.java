package manager;

import client.InputClient;
import errors.ErrorToJsonFile;
import mainobject.Account;
import mainobject.Customer;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static dbQueries.ExecuteQueries.fillAccountsTable;
import static dbQueries.ExecuteQueries.fillcustomersTable;
import static validations.AccountPredicates.*;
import static validations.CustomerPredicates.*;


public class DTOManagment {

    //CSV file header
    private static final String [] FILE_HEADER_MAPPING_Accounts = {"recordNumber","accountNumber","accountType","accountCustomerId","accountOpenDate","accountBalance"};
    private static final String [] FILE_HEADER_MAPPING_customer = {"recordNumber","customerId","customerName","customerSurname","customerAddress","customerZipCode","customerNationalId","customerBirthDate"};

    /**
     * This methode does above process for Customers info.
     *
     * @param startIndex
     * @param maxSize
     */

    public static void manageCustomers(int startIndex, int maxSize) {

        ResourceBundle bundle = ResourceBundle.getBundle("DB");
        String root = System.getProperty("user.dir");
        String filepathAccounts = bundle.getString("filepathCustomers");
        String abspathcCustomers = root+filepathAccounts;

        final String FILE_NAME = "Customer";
        final int INVALID_BIRTHDAY_ERROR_CODE = 450;
        final int INVALID_NATHONAL_ID_ERROR_CODE = 455;
        final String BUSINESS_ERROR = "Business Error";

        //********************************* read from csv file *********************************************
        Reader in = null;
        try {
            in = new FileReader(abspathcCustomers);
        } catch (FileNotFoundException e) {
            System.out.println("DTOManagment fileCustomers" + e.getMessage());
        }

        // Read its data
        CSVParser csvParser = null;
        try {
            csvParser = new CSVParser(in, CSVFormat.DEFAULT
                    .withHeader(FILE_HEADER_MAPPING_customer));
            //********************* convert to customers objects *************************************
            List<Customer> customers = StreamSupport.stream(csvParser.spliterator(), false)
                    .skip(startIndex).limit(maxSize)
                    .map((CSVRecord csvRecord) -> Customer.parse(csvRecord))
                    .collect(Collectors.toList());

/*
            List < Customer > employees = List.of(); // Default to empty non-modifiable list.

            //  Path path = Paths.get( "/Users/basilbourque/csv.txt" );
            try (
                    Reader reader = Files.newBufferedReader(Path.of(abspathcCustomers), StandardCharsets.UTF_8 );
            )
            {
                Iterable < CSVRecord > iterable = CSVFormat.DEFAULT
                        .withHeader(FILE_HEADER_MAPPING_customer).parse( reader );
                employees =
                        StreamSupport
                                .stream( iterable.spliterator() , false )
                                .map( ( CSVRecord csvRecord ) -> Customer.parse( csvRecord ) )
                                .collect( Collectors.toList() )
                ;
            }
            catch ( IOException e )
            {
                e.printStackTrace();
            }*/

            //********************* validation by predicates and log invalid data to json file *************************************
            List<Customer> invalidBirthDateCustomers = filterInvalidCustomers(customers, isBirthDateInvalid());
            if (invalidBirthDateCustomers != null && invalidBirthDateCustomers.size() != 0) {
                List<Long> ids = invalidBirthDateCustomers.stream().map(i -> i.getCustomerId()).collect(Collectors.toList());
                ErrorToJsonFile.manageErrors(FILE_NAME, ids, INVALID_BIRTHDAY_ERROR_CODE, BUSINESS_ERROR, "سال تولد نامعتبر است");
            }

            List<Customer> invalidNatinalIdCustomers = filterInvalidCustomers(customers, isNationalIdInvalid());
            if (invalidNatinalIdCustomers != null && invalidNatinalIdCustomers.size() != 0) {
                List<Long> ids = invalidNatinalIdCustomers.stream().map(i -> i.getCustomerId()).collect(Collectors.toList());
                ErrorToJsonFile.manageErrors(FILE_NAME, ids, INVALID_NATHONAL_ID_ERROR_CODE, BUSINESS_ERROR, "کدملی نامعتبر است");
            }
            //********************* insert valid customers to database *************************************
            customers.removeAll(invalidBirthDateCustomers);
            customers.removeAll(invalidNatinalIdCustomers);
            fillcustomersTable(customers);

            //********************* add invalid customer ids to global list *************************************
            List<Customer> invalidCustomers = new ArrayList<>();
            invalidCustomers.addAll(invalidBirthDateCustomers);
            invalidCustomers.addAll(invalidNatinalIdCustomers);
            InputClient.addToIds(invalidCustomers != null ? invalidCustomers.stream().map(i -> i.getCustomerId()).collect(Collectors.toList()) : null);

        } catch (IOException e) {
            System.out.println("DTOManagment" + e.getMessage());
        }

    }

    /**
     * This methode does above process for accounts info.
     *
     * @param startIndex
     * @param maxSize
     */
    public static void manageAccounts(int startIndex, int maxSize) {

        ResourceBundle bundle = ResourceBundle.getBundle("DB");
        String root = System.getProperty("user.dir");
        String filepathAccounts = bundle.getString("filepathAccounts");
        String abspathAccounts = root+filepathAccounts;

        final String FILE_NAME = "Account";
        final int INVALID_BALANCE_ERROR_CODE = 400;
        final int INVALID_TYPE_ERROR_CODE = 401;
        final int INVALID_NUMBER_ERROR_CODE = 402;
        final String BUSINESS_ERROR = "Business Error";
        //********************************* read from csv file *********************************************
        Reader in = null;
        try {
            in = new FileReader(abspathAccounts);
        } catch (FileNotFoundException e) {
            System.out.println("DTOManagment fileAccounts" + e.getMessage());
        }

        // Read its data
        CSVParser csvParser = null;
        try {
            csvParser = new CSVParser(in, CSVFormat.DEFAULT
                    .withHeader(FILE_HEADER_MAPPING_Accounts));


            //********************* converting to Accounts objects *************************************

            List<Account> accounts = StreamSupport.stream(csvParser.spliterator(), false)
                    .skip(startIndex).limit(maxSize)
                    .map((CSVRecord csvRecord) -> Account.parse(csvRecord))
                    .collect(Collectors.toList());

            //********************* validation by predicates and log invalid data to json file *************************************

            List<Account> invalidBalanceAccounts = filterInvalidAccounts(accounts, isBalanceInvalid());
            if (invalidBalanceAccounts != null && invalidBalanceAccounts.size() != 0) {
                List<Long> ids = invalidBalanceAccounts.stream().map(i -> i.getRecordNumber()).collect(Collectors.toList());
                ErrorToJsonFile.manageErrors(FILE_NAME, ids, INVALID_BALANCE_ERROR_CODE, BUSINESS_ERROR, "مقدار اکانت بالانس نمی تواند از مقدار مجاز بیشتر باشد");
            }

            List<Account> invalidTypeAccounts = filterInvalidAccounts(accounts, isTypeInvalid());
            if (invalidTypeAccounts != null && invalidTypeAccounts.size() != 0) {
                List<Long> ids = invalidTypeAccounts.stream().map(i -> i.getRecordNumber()).collect(Collectors.toList());
                ErrorToJsonFile.manageErrors(FILE_NAME, ids, INVALID_TYPE_ERROR_CODE, BUSINESS_ERROR, "نوع اکانت متناسب با انواع تعریف شده نیست");
            }
            List<Account> invalidNumberAccounts = filterInvalidAccounts(accounts, isNumbervalid());
            if (invalidNumberAccounts != null && invalidNumberAccounts.size() != 0) {
                List<Long> ids = invalidNumberAccounts.stream().map(i -> i.getRecordNumber()).collect(Collectors.toList());
                ErrorToJsonFile.manageErrors(FILE_NAME, ids, INVALID_NUMBER_ERROR_CODE, BUSINESS_ERROR, "شماره حساب نامعتبر است");
            }


            //********************* insert valid Accounts to database *************************************
            accounts.removeAll(invalidBalanceAccounts);
            accounts.removeAll(invalidTypeAccounts);
            accounts.removeAll(invalidNumberAccounts);
            // accounts.removeAll(invalidCustomerAccounts);
            fillAccountsTable(accounts);

            //********************* add invalid customer ids to global list *************************************
            List<Account> invalidAccounts = new ArrayList<>();
            invalidAccounts.addAll(invalidBalanceAccounts);
            invalidAccounts.addAll(invalidTypeAccounts);
            invalidAccounts.addAll(invalidNumberAccounts);
            InputClient.addToIds(invalidAccounts != null ? invalidAccounts.stream().map(i -> i.getRecordNumber()).collect(Collectors.toList()) : null);


        } catch (IOException e) {
            System.out.println("DTOManagment" + e.getMessage());
        }


    }


}