package client;

import java.util.ArrayList;
import java.util.List;

import static jobs.JobsManagment.executeAccountJobs;
import static jobs.JobsManagment.executeCustomerJobs;

public class InputClient {
    /** This is a global variable for keeping invalid customer ids used by jobs, to
     * validate accounts and removing them without invalid customer_id
     * (avoiding foreign key constraint error))
     */
   public static List<Long> invalidIds = new ArrayList<>();

    /** This methode is used by jobs to add invalid customer ids, and beacuse of
     * non-thread-safety of list, it must be synchronized
     */
    public static synchronized void addToIds(List<Long> ids){ invalidIds.addAll(ids);}

    /** this is main methode or runner of module 1, that calls methode for managing jobs */
    public static void main(String arg[])
    {
        executeAccountJobs();
        executeCustomerJobs();
      //  manageCustomers(1,3);

    }


}
