package dbQueries;

import dbcp.ExecuteDBCP;
import mainobject.Account;
import mainobject.Customer;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class ExecuteQueries {

    private static final String SQL_INSERT_Customers = "INSERT INTO Customers (RecordNumber,CustomerId,CustomerName,CustomerSurname,CustomerAddress,CustomerZipCode,CustomerNationalId,CustomerBirthDate) VALUES (?,?,?,?,?,?,?,?) ";
    private static final String SQL_INSERT_Accounts = "INSERT INTO Accounts ([RecordNumber],[AccountNumber],[AccountType],[AccountCustomerId],[AccountOpenDate],[AccountBalance]) VALUES (?,?,?,?,?,?) ";


    /** This methode inserts a list of Customer in DB */
    public static void fillcustomersTable(List<Customer> customers)
    {
        /** Query of insert data via question marks */
        String query = SQL_INSERT_Customers;
        /** Get connection from dbcp datasource */
        DataSource ds = ExecuteDBCP.getDataSource();
        Connection conn = null;
        PreparedStatement pStmt = null;

        /** Execute queries; that inserts all records in list and will be committed once */
        try
        {
            conn = ds.getConnection();
            PreparedStatement st = conn.prepareStatement(query);
            for(Customer customer : customers){
                st.setInt(1,  customer.recordNumber);
                st.setLong(2,  customer.customerId);
                st.setString(3,  customer.customerName);
                st.setString(4,  customer.customerSurname);
                st.setString(5,  customer.customerAddress);
                st.setString(6,  customer.customerZipCode);
                st.setString(7,  customer.customerNationalId);
                st.setInt(8,  customer.customerBirthDate);
                st.addBatch();
                System.out.println(customer.recordNumber);
            }
            st.executeBatch();
        }
        catch (SQLException e) {
            System.out.println("Execute queries - fillcustomer/table" + e.getMessage());
            try {
                conn.rollback();
            } catch (SQLException ex) {
                System.out.println("Execute queries - fillcustomer/table" + ex.getMessage());
            }
        }
/*        finally {
            try
            {
                pStmt.close();
                //conn.close();
            } catch (SQLException e){
                System.out.println("dd");
            }
        }*/
    }


    /** This methode inserts a list of accounts in DB */
    public static void fillAccountsTable(List<Account> accounts)
    {
        /** Query of insert data via question marks */
        String query = SQL_INSERT_Accounts;
        /** Get connection from dbcp datasource */
        DataSource ds = ExecuteDBCP.getDataSource();
        Connection conn = null;
        PreparedStatement pStmt = null;

        /** Execute queries; that inserts all records in list and will be committed once */
        try
        {
            conn = ds.getConnection();
            PreparedStatement st = conn.prepareStatement(query);
            for(Account account : accounts){
                st.setLong(1,  account.recordNumber);
                st.setString(2,  account.accountNumber);
                st.setInt(3,  account.accountType);
                st.setInt(4,  account.accountCustomerId);
                st.setInt(5,  account.accountOpenDate);
                st.setInt(6,  account.accountBalance);
                st.addBatch();
                System.out.println(account.recordNumber);
            }
            st.executeBatch();

        }
        catch (SQLException e) {
            System.out.println("Execute queries - fillAccounts/table" + e.getMessage());
            try {
                conn.rollback();
            } catch (SQLException ex) {
                System.out.println("Execute queries - fillAccounts/table" + ex.getMessage());
            }
        }
       /* pariii finally {
            try
            {
                pStmt.close();
                //conn.close();
            } catch (SQLException e){
                System.out.println("dd");
            }
        }*/
    }





}
