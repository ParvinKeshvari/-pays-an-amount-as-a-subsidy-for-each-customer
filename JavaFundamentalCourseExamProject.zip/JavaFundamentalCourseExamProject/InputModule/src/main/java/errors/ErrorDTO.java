package errors;

public class ErrorDTO {

    public String FileName;
    public long RecordNumber;
    public String ErrorCode;
    public String ErrorClassificationName;
    public String ErrorDescription;
    public String ErrorDate;


    public ErrorDTO()
    {

    }

    public String getFileName() {
        return FileName;
    }

    public void setFileName(String fileName) {
        FileName = fileName;
    }

    public long getRecordNumber() {
        return RecordNumber;
    }

    public void setRecordNumber(long recordNumber) {
        RecordNumber = recordNumber;
    }

    public String getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(String errorCode) {
        ErrorCode = errorCode;
    }

    public String getErrorClassificationName() {
        return ErrorClassificationName;
    }

    public void setErrorClassificationName(String errorClassificationName) {
        ErrorClassificationName = errorClassificationName;
    }

    public String getErrorDescription() {
        return ErrorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        ErrorDescription = errorDescription;
    }

    public String getErrorDate() {
        return ErrorDate;
    }

    public void setErrorDate(String errorDate) {
        ErrorDate = errorDate;
    }

    @Override
    public String toString() {
        return "ErrorJSONClass{" +
                "FileName='" + FileName + '\'' +
                ", RecordNumber='" + RecordNumber + '\'' +
                ", ErrorCode='" + ErrorCode + '\'' +
                ", ErrorClassificationName='" + ErrorClassificationName + '\'' +
                ", ErrorDescription='" + ErrorDescription + '\'' +
                ", ErrorDate='" + ErrorDate + '\'' +
                '}';
    }
}
