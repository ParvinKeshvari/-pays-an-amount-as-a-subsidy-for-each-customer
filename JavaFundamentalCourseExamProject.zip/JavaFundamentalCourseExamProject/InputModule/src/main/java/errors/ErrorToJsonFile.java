package errors;

import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.locks.ReentrantLock;

import static writetofile.writeToFile.writeToJsonFile;

public class ErrorToJsonFile {

    public static void manageErrors(String fileName, List<Long> recordNumbers,
                                    int errorcode,String errorClassificationName, String errorDesc)
    {
        ReentrantLock lock = new ReentrantLock();
        lock.lock();
        ResourceBundle bundle = ResourceBundle.getBundle("DB");
        String root = System.getProperty("user.dir");
        String fileErrorJSONFile = bundle.getString("fileErrorJSONFile");

        //String filepathAccounts = "\\src\\main\\resources\\data\\ErrorJSONFile.json";
        String abspathfileErrorJSONFile = root + fileErrorJSONFile;

        for(long recordNumber : recordNumbers) {
            // this method create an error object by ErrorDto setter
            ErrorDTO error = createError(fileName, recordNumber, errorcode, errorClassificationName, errorDesc);

        /*    // this generic method writes error created in pervious step in json file.
            writeToJsonFile("errors.json", error);*/

            //If you want it in a specific datatype, use Stream.of(object):
            List<Object> list = Collections.singletonList(error);


            // this generic method writes error created in pervious step in json file.
            writeToJsonFile( list,abspathfileErrorJSONFile);
        }
        lock.unlock();
        }



    /** This method create an error object by ErrorDTO setters */
    public static ErrorDTO createError (String fileName, long recordNo,
                                    int errorcode,String errorClassificationName, String errorDesc)
    {

        ErrorDTO errorJSONClass = new ErrorDTO();
        errorJSONClass.setFileName(fileName);
        errorJSONClass.setRecordNumber(recordNo);
        errorJSONClass.setErrorCode(String.valueOf(errorcode));
        errorJSONClass.setErrorClassificationName(errorClassificationName);
        errorJSONClass.setErrorDescription(errorDesc);
        errorJSONClass.setErrorDate("errorDate");


        return errorJSONClass;
    }

}
