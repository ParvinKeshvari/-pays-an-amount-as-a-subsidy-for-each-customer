package mainobject;


import org.apache.commons.csv.CSVRecord;

import java.util.Objects;

public class Customer {

    public int recordNumber;
    public long customerId;
    public String customerName;
    public String customerSurname;
    public String customerAddress;
    public String customerZipCode;
    public String customerNationalId;
    public int customerBirthDate;

    public Customer(int recordNumber, long customerId, String customerName, String customerSurname, String customerAddress, String customerZipCode, String customerNationalId, int customerBirthDate) {
        this.recordNumber = recordNumber;
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerSurname = customerSurname;
        this.customerAddress = customerAddress;
        this.customerZipCode = customerZipCode;
        this.customerNationalId = customerNationalId;
        this.customerBirthDate = customerBirthDate;
    }

    public Customer()
    {
    }
    static public Customer parse ( CSVRecord csvRecord )
    {
        int recordNumber = Integer.parseInt(Objects.requireNonNull( csvRecord.get( "recordNumber" )));
        long customerId = Long.parseLong(Objects.requireNonNull( csvRecord.get( "customerId" ) ));
        String customerName = Objects.requireNonNull( csvRecord.get( "customerName" ) );
        String customerSurname = Objects.requireNonNull( csvRecord.get( "customerSurname" ) );
        String customerAddress = Objects.requireNonNull( csvRecord.get( "customerAddress" ) );
        String customerZipCode = Objects.requireNonNull( csvRecord.get( "customerZipCode" ) );
        String customerNationalId = Objects.requireNonNull( csvRecord.get( "customerNationalId" ) );
        int customerBirthDate =  Integer.parseInt(Objects.requireNonNull( csvRecord.get( "customerBirthDate" )) );



        Customer customer = new Customer( recordNumber,customerId, customerName, customerSurname, customerAddress, customerZipCode, customerNationalId, customerBirthDate) ;
        Objects.requireNonNull( customer );
        return customer;
    }


    public int getRecordNumber() {
        return recordNumber;
    }

    public void setRecordNumber(int recordNumber) {
        this.recordNumber = recordNumber;
    }

    public long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerSurname() {
        return customerSurname;
    }

    public void setCustomerSurname(String customerSurname) {
        this.customerSurname = customerSurname;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public String getCustomerZipCode() {
        return customerZipCode;
    }

    public void setCustomerZipCode(String customerZipCode) {
        this.customerZipCode = customerZipCode;
    }

    public String getCustomerNationalId() {
        return customerNationalId;
    }

    public void setCustomerNationalId(String customerNationalId) {
        this.customerNationalId = customerNationalId;
    }

    public int getCustomerBirthDate() {
        return customerBirthDate;
    }

    public void setCustomerBirthDate(int customerBirthDate) {
        this.customerBirthDate = customerBirthDate;
    }

    // Parsing from Apache Commons CSV record

    /**
     * @return برگرداندن آبجکت وریبل
     */
    @Override
    public String toString() {
        return "Customers{" +
                "recordNumber=" + recordNumber +
                ", customerId=" + customerId +
                ", customerName='" + customerName + '\'' +
                ", customerSurname='" + customerSurname + '\'' +
                ", customerAddress='" + customerAddress + '\'' +
                ", customerZipCode='" + customerZipCode + '\'' +
                ", customerNationalId=" + customerNationalId +
                ", customerBirthDate=" + customerBirthDate +
                '}';
    }

/*    *//**
     * چک کردن سال تولد مشتری
     * @author keshvari
     * @throws CustomerBirthDateException
     *//*
    public void checkedCustomerBirthDate() throws CustomerBirthDateException
    {
        if(getCustomerBirthDate()>1373)
        {
            throw new CustomerBirthDateException("تاریخ تولد باید بزرگتر از 1373 باشد");
        }
    }

    *//**
     * چک کردن معتبر بودن کد ملی
     * @author keshvari
     * @throws CustomerNationalIdException
     *//*
    public void checkedCustomerNationalId() throws CustomerNationalIdException
    {
        if(getCustomerNationalId().length() != 10)
        {
            throw new CustomerNationalIdException("کد ملی نامعتبر است");
        }
    }


    *//**
     * چک کردن آی دی مشتری
     * @author keshvari
     * @throws CustomerIdException
     *//*
    public void checkedCustomerId() throws CustomerIdException
    {
       *//* if(getCustomerNationalId().length() != 10)
        {
            throw new CustomerIdException("آی دی مشتری نامعتبر است");
        }*//*
    }*/


}
