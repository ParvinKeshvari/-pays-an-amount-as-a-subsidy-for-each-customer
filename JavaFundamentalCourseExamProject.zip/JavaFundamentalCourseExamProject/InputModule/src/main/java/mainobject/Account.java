package mainobject;


import org.apache.commons.csv.CSVRecord;

import java.util.Objects;

/**
 * This is Account object Class
 * @author keshvari
 */
public class Account {

    public static final long accountLimit = 20000;
    public long recordNumber;
    public String accountNumber;
    public int accountType;
    public int accountCustomerId;
    public int accountOpenDate;
    public int accountBalance;


    public Account()
    {

    }

    public Account(long recordNumber, String accountNumber, int accountType, int accountCustomerId, int accountOpenDate, int accountBalance) {
        this.recordNumber = recordNumber;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.accountCustomerId = accountCustomerId;
        this.accountOpenDate = accountOpenDate;
        this.accountBalance = accountBalance;
    }

    static public Account parse (CSVRecord csvRecord )
    {
        Long recordNumber = Long.parseLong(Objects.requireNonNull( csvRecord.get( "recordNumber" )));
        String accountNumber = Objects.requireNonNull( csvRecord.get( "accountNumber" ) );
        int accountType = Integer.parseInt(Objects.requireNonNull( csvRecord.get( "accountType" )) );
        int accountCustomerId =  Integer.parseInt(Objects.requireNonNull( csvRecord.get( "accountCustomerId" )) );
        int accountOpenDate =  Integer.parseInt(Objects.requireNonNull( csvRecord.get( "accountOpenDate" )) );
        int accountBalance =  Integer.parseInt(Objects.requireNonNull( csvRecord.get( "accountBalance" )) );

        Account account = new Account( recordNumber, accountNumber,accountType,accountCustomerId,accountOpenDate,accountBalance);
        Objects.requireNonNull( account );
        return account;
    }

    public long getRecordNumber() {
        return recordNumber;
    }

    public void setRecordNumber(long recordNumber) {
        this.recordNumber = recordNumber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public int getAccountType() {
        return accountType;
    }

    public void setAccountType(int accountType) {
        this.accountType = accountType;
    }

    public int getAccountCustomerId() {
        return accountCustomerId;
    }

    public void setAccountCustomerId(int accountCustomerId) {
        this.accountCustomerId = accountCustomerId;
    }

    public long getAccountLimit() {
        return accountLimit;
    }

    /*public void setAccountLimit(long accountLimit) {
        this.accountLimit = accountLimit;
    }
*/
    public int getAccountOpenDate() {
        return accountOpenDate;
    }

    public void setAccountOpenDate(int accountOpenDate) {
        this.accountOpenDate = accountOpenDate;
    }

    public long getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(int accountBalance) {
        this.accountBalance = accountBalance;
    }

    /**
     * @return برگرداندن آبجکت وریبل
     */
    @Override
    public String toString() {
        return "Accounts{" +
                "recordNumber=" + recordNumber +
                ", accountNumber=" + accountNumber +
                ", accountType=" + accountType +
                ", accountCustomerId=" + accountCustomerId +
                ", accountLimit=" + accountLimit +
                ", accountOpenDate=" + accountOpenDate +
                ", accountBalance=" + accountBalance +
                '}';
    }


/*
    */
/**
     * چک کردن طول شماره حساب که باید 22 رقم باشد
     * @author keshvari
     * @throws AccountNumberException
     *//*

    public void checkedAccountNumber() throws AccountNumberException
    {
        if(accountNumber.length() != 22)
            throw new AccountNumberException("شماره حساب با احتساب صفرهای ابتدایی باید 22 رقمی باشد");
    */
/*    Pattern pattern = Pattern.compile("^0\\d{21}$");
        Matcher matcher = pattern.matcher(getAccountNumber());
        if(!matcher.find())
        {
            throw new AccountNumberException("شماره حساب با احتساب صفرهای ابتدایی باید 22 رقمی باشد");
        }*//*

    }

    */
/**
     * چک کردن موجودی حساب به منظور موجودی حساب نامعتبر است یا خیر
     * @author keshvari
     * @throws AccountBalanceValidationException
     *//*

    public void checkedAccountBalance() throws AccountBalanceValidationException
    {
        if(getAccountBalance()>getAccountLimit())
        {
            throw new AccountBalanceValidationException("موجودی حساب نامعتبر است");
        }
    }

    */
/**
     *  چک کردن نوع حساب به منظور اینکه نوع حساب نامعتبر است یا خیر
     * @author keshvari
     * @throws AccountTypeException
     *//*

    public void checkedAccountType() throws AccountTypeException
    {
        if(getAccountType()<1 || getAccountType()>3)
        {
            throw new AccountTypeException("نوع حساب نامعتبر است");
        }
    }
*/



}
